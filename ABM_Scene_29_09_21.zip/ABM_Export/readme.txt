PolygonalMind

*********************


This is a folder created to gather the Decentraland Export made by the Unity Plugin

- Be sure you have installed the Node.js software and the Decentraland SDK or IT WONT WORK.

- Then just run "RunDCL.ink"

- DeleteDCL is to delete node_modules and the bin folder, it won't affect the rest of your assets. This is suitable to reinstall the sdk in your project